int r,c;
int transpose(int arr[r][c]);
int pointertranspose(int * ptr);